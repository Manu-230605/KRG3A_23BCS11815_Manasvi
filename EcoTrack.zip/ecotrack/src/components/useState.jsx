import useWindowSize from "./useWindowSize";

function App() {
  const { width, height } = useWindowSize();

  return (
    <div>
      <h2>Window Width: {width}px</h2>
      <h2>Window Height: {height}px</h2>
    </div>
  );
}

export default App;
